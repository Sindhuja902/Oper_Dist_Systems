import socket
import threading
from datetime import datetime


def Client():
    host = socket.gethostname()
    port = 4070
    client_socket = socket.socket()

    data = ""
    while data == "":
        client_socket.connect((host, port))
        data = client_socket.recv(1024).decode()
    name = threading.current_thread().name + "->"
    print(name, end=" ")
    client_socket.close()


if __name__ == '__main__':
    startTime = datetime.now()
    print("Client request start time:", datetime.now())
    threadsList = []
    for i in range(100):
        t = threading.Thread(target=Client, name="thread" + str(i))
        t.start()
        threadsList.append(t)
    for t in threadsList:
        t.join()
    endTime = datetime.now()
    print("client end time", datetime.now())
    print("Time Taken=", (endTime - startTime).total_seconds() * 100)

