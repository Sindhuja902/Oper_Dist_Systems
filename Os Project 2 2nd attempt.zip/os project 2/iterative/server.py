import socket
import threading
import time
from datetime import datetime

total = 0
threadStartTimes = []
threadEndtimes = []
printingValue = ""

def serverThread(conn, address):

    global threadStartTimes
    startTime = datetime.now()
    threadStartTimes.append(startTime)
    tot = 0
    for i in range(90000):
        tot += 1
    name = threading.current_thread().name + "    active threads:" + str(threading.active_count()) + "\t"
    global printingValue
    printingValue += name
    data = "connected"
    conn.send(data.encode())
    conn.close()

    global threadEndtimes
    endTime = datetime.now()
    threadEndtimes.append(endTime)


def Iterative_Server():
    host = socket.gethostname()
    port = 4070
    server_socket = socket.socket()
    server_socket.bind((host, port))
    server_socket.listen(100)
    print("Iterative Server started", datetime.now())

    threadsList = []

    while True:

        conn, address = server_socket.accept()
        global total
        total += 1
        t = threading.Thread(target=serverThread, name="thread" + str(total), args=(conn, address,))
        threadsList.append(t)
        t.start()
        t.join()
        if total == 100: break

    print("total connected clients=", total)
    server_socket.close()


Iterative_Server()
print(printingValue)
startTime = min(threadStartTimes)
endTime = max(threadEndtimes)
print("iterative server ended", datetime.now())
print("TimeTaken=", (endTime - startTime).total_seconds() * 100)
