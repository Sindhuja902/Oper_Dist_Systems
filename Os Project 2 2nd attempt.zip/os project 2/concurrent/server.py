import socket
import threading
import time
from datetime import datetime

total = 0
threadStartTimes = []
threadEndtimes = []
printingValue = ""


def serverThread(conn, address):

    global threadStartTimes
    startTime = datetime.now()
    threadStartTimes.append(startTime)
    tot = 0
    for i in range(90000):
        tot += 1
    name = threading.current_thread().name + "    active threads:" + str(threading.active_count()) + "\t"
    global printingValue
    printingValue += name
    data = "connected"
    conn.send(data.encode())
    conn.close()
    # this is note down the end times of each thread of server
    global threadEndtimes
    endTime = datetime.now()
    # endTime=(((datetime.now() - datetime(1970, 1, 1)).total_seconds())%1000)*1000
    threadEndtimes.append(endTime)
    return


def Concurrent_Server():
    host = socket.gethostname()
    port = 4070
    server_socket = socket.socket()
    server_socket.bind((host, port))
    server_socket.listen(100)
    print("Concurrent server started", datetime.now())

    threadsList = []
    while True:

        conn, address = server_socket.accept()
        global total
        total += 1
        t = threading.Thread(target=serverThread, name="thread" + str(total), args=(conn, address,))
        threadsList.append(t)
        t.start()
        if total == 100: break

    print("total connected clients=", total)
    server_socket.close()


Concurrent_Server()
print(printingValue)

startTime = min(threadStartTimes)

endTime = max(threadEndtimes)
print("Concurrent server ended", datetime.now())
print("Time Taken=", (endTime - startTime).total_seconds() * 100)
